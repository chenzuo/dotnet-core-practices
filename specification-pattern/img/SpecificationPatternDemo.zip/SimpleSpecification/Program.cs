﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SimpleSpecification;

namespace SimpleSpecification
{
    class Program
    {
        static void Main(string[] args)
        {
            Demo3();
            Console.Read();
        }

        public static void Demo3()
        {
            var items = Enumerable.Range(-5, 10);
            Console.WriteLine("产生的数组为：{0}", string.Join(",  ", items.ToArray()));

           Func<int, bool> evenSpec = it => it % 2 == 0;

            var compositeSpec = GetCompositeSpec(evenSpec);

            foreach (var i in items.Where(it => compositeSpec(it)))
            {
                Console.WriteLine(i);
            }
        }

        private static Func<int, bool> GetCompositeSpec(Func<int, bool> spec)
        {
            return spec.And(it => it > 0);
        }
    }
}
