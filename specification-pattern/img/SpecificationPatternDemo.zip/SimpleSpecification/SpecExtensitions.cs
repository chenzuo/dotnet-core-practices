﻿using System;

namespace SimpleSpecification
{
    // 更轻量的实现
    public static  class SpecExtensitions
    {
        public static Func<T, bool> And<T>(this Func<T, bool> left, Func<T, bool> right)
        {
            return candidate => left(candidate) && right(candidate);
        }

        public static Func<T, bool> Or<T>(this Func<T, bool> left, Func<T, bool> right)
        {
            return candidate => left(candidate) || right(candidate);
        }

        public static Func<T, bool> Not<T>(this Func<T, bool> one)
        {
            return candidate => !one(candidate);
        }
    }
}