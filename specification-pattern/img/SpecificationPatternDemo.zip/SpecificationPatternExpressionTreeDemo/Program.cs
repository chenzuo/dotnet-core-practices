﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using SpecificationPatternExpressionTreeDemo;

namespace SpecificationPatternExpressionTreeDemo
{
    class Program
    {
        private static void Main(string[] args)
        {
            Demo1();
            Console.Read();
        }

        public static void Demo1()
        {
            var items = Enumerable.Range(-5, 10);
            Console.WriteLine("产生的数组为：{0}", string.Join(",  ", items.ToArray()));

            Expression<Func<int, bool>> f = i => i % 2 != 0;
            f = f.Not().And(i => i > 0);

            // 通过AsQueryable成IQueryable<int>,因为IQueryable<T>的Where方法的参数要求是表达式树
            foreach (var i in items.AsQueryable().Where(f))
            {
                Console.WriteLine(i);
            }
        }
    }
}
