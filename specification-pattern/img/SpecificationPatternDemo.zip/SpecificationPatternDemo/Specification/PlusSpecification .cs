﻿namespace SpecificationPatternDemo.Specification
{
    // 具体的规约，正数规约
    public class PlusSpecification  : CompositeSpecification<int>
    {
        public override bool IsSatisfiedBy(int candidate)
        {
            return candidate > 0;
        }
    }
}