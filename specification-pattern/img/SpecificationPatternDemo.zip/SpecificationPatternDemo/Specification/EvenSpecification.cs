﻿namespace SpecificationPatternDemo.Specification
{
    // 具体规约，偶数规约
    public class EvenSpecification : CompositeSpecification<int>
    {
        public override bool IsSatisfiedBy(int candidate)
        {
            return candidate % 2 == 0;
        }
    }
}