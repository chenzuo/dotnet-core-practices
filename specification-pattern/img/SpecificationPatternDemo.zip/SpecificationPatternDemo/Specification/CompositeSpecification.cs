﻿namespace SpecificationPatternDemo.Specification
{
    // 因为And,OR和Not方法在所有的Specification都需要实现，只有IsSatisfiedBy方法才依赖业务规则
    // 所以为了复用，定义一个抽象类来实现And,Or和And操作,并且留IsSatisfiedBy方法给子类去实现，所以定义其为abstract
    public abstract class CompositeSpecification<T>: ISpecification<T>
    {
        public abstract bool IsSatisfiedBy(T candidate);

        public ISpecification<T> And(ISpecification<T> specification)
        {
            return new AndSpecification<T>(this, specification);
        }

        public ISpecification<T> Or(ISpecification<T> specification)
        {
            return new OrSpecification<T>(this, specification);
        }

        public ISpecification<T> Not(ISpecification<T> specification)
        {
            return new NotSpecification<T>(specification);
        }
    }
}