﻿namespace SpecificationPatternDemo.Specification_2
{
    public interface ISpecification<in T>
    {
        bool IsSatisfiedBy(T candidate);
    }
}