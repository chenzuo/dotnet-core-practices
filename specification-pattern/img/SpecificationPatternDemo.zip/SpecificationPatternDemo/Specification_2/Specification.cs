﻿using System;

namespace SpecificationPatternDemo.Specification_2
{
    public class Specification<T> : ISpecification<T>
    {
        private readonly Func<T, bool> _isSatisfiedBy;

        public Specification(Func<T, bool> isSatisfiedBy)
        {
            this._isSatisfiedBy = isSatisfiedBy;
        }

        public bool IsSatisfiedBy(T candidate)
        {
            return _isSatisfiedBy(candidate);
        }

    }
}