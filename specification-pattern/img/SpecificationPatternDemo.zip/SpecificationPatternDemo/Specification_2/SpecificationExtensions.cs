﻿namespace SpecificationPatternDemo.Specification_2
{
    public static class SpecificationExtensions
    {
        public static ISpecification<T> And<T>(this ISpecification<T> left, ISpecification<T> right)
        {
            return new Specification<T>(candidate => left.IsSatisfiedBy(candidate) && right.IsSatisfiedBy(candidate));
        }

        public static ISpecification<T> Or<T>(this ISpecification<T> left, ISpecification<T> right)
        {
            return new Specification<T>(candidate => left.IsSatisfiedBy(candidate) || right.IsSatisfiedBy(candidate));
        }

        public static ISpecification<T> Not<T>(this ISpecification<T> one)
        {
            return new Specification<T>(candidate => !one.IsSatisfiedBy(candidate));
        }
    }
}