﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SpecificationPatternDemo.Specification_2;
using spec1 =SpecificationPatternDemo.Specification;
using spec2 = SpecificationPatternDemo.Specification_2;

namespace SpecificationPatternDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Demo2();
            Console.Read();
        }

        public static void Demo1()
        {
            var items = Enumerable.Range(-5, 10);
            Console.WriteLine("产生的数组为：{0}", string.Join(",  ", items.ToArray()));
            spec1.ISpecification<int> evenSpec = new spec1.EvenSpecification();
            // 获得一个组合规约
            var compositeSpecification = GetCompositeSpecification(evenSpec);
            // 类似Where(it=>it%2==0 && it > 0)
            // 前者是把两个条件合并写死成一个条件，而后者是将其组合成一个新条件。就如拼图出一架飞机和直接制造一个飞机模型概念是完全不同的
            foreach (var item in items.Where(it=>compositeSpecification.IsSatisfiedBy(it)))
            {
                // 输出既是正数又是偶数的数
                Console.WriteLine(item);
            }
        }

        private static spec1.ISpecification<int> GetCompositeSpecification(spec1.ISpecification<int> spec)
        {
            spec1.ISpecification<int> plusSpec = new spec1.PlusSpecification();
            return spec.And(plusSpec);
        }

        public static void Demo2()
        {
            var items = Enumerable.Range(-5, 10);
            Console.WriteLine("产生的数组为：{0}", string.Join(",  ", items.ToArray()));
            spec2.ISpecification<int> evenSpec = new spec2.Specification<int>(it => it % 2 == 0);

            var compositeSpec = GetCompositeSpecification2(evenSpec);

            foreach (var i in items.Where(it => compositeSpec.IsSatisfiedBy(it)))
            {
                Console.WriteLine(i);
            }
        }

        private static spec2.ISpecification<int> GetCompositeSpecification2(spec2.ISpecification<int> spec)
        {
            spec2.ISpecification<int> plusSpec = new spec2.Specification<int>(it => it > 0);
            return spec.And(plusSpec);
        }
    }
}
